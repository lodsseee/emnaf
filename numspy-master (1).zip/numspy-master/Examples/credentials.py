username = 'your way2sm username'
password = 'your way2sms password'
mobile_number = 'receivers mobile number'